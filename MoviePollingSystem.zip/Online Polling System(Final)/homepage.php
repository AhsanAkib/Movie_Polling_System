<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Homepage</title>
	<link rel="stylesheet" href="css/homepage.css">
</head>
<body>
	<div class="query"><marquee>Are you a Movie enthusiast?</marquee></div>
	<nav class="main-menu">
	 			<div class="logo">
	 			</div>
			 	<ul>
                    <li><a class="current" href="#">Home</a></li>
					<li><a href="#movie">Movies</a></li>
					<li><a href="voterprofile.php">Profile</a></li>
					<li><a href="#contact">Contact</a></li>
				</ul>
	</nav>
			 
	 <header class="header-part">
	 	<div class="header-overlay">
	 		<div class="kilibili">
	 			<div class="content text-center">
					 
<!--JSON used-->

					<p><button id="showInfo" style="font-size: 20px; font-style: bolder">Go to info</button></p> <br>
                    <div id="showme" style="color: black"></div>
                    <script>
                        document.getElementById("showInfo").addEventListener('click', onProcess);
                        function onProcess(){
                            var req = new XMLHttpRequest();
                            req.open('GET', 'profileUpdate.json', true);
                            req.onload = function() {
                                if(req.status==200){
                                    var dataItem = JSON.parse(req.responseText);
                                    var display = '';
                                    display += '<ol>'+
                                        '<li>1: '+dataItem.a+'</li>'+
                                        '<li>2: '+dataItem.b+'</li>'+
                                        '<li>3: '+dataItem.c+'</li>'+
                                        '<li>4: '+dataItem.d+'</li>'+
                                        '<li>5: '+dataItem.e+'</li>'+
                                        '</ol>';
                            document.getElementById('showme').innerHTML = display;
                                }
                            } 
                            req.send();
						}
						

                    </script>
                    </div>
				</div>
	 		</div>
	 	</div>
	 </header>

	 <section id="movie">
		<h1>Movies</h1><br>

		<div class="services">
			<div class="ser-container">
			<div class="service-item">
				<div class="pic-size">

					<a href="thrillermovie.php" target="_blank"><img src="img/m1.jpg" height="200px" width="200px"></a>

				</div>
				<div class="service-content">Thriller</p>		
				</div>
			</div>
		</div>

		<div class="services">
			<div class="ser-container">
			<div class="service-item">
				<div class="pic-size">
					<a href="actionmovie.php" target="_blank"><img src="img/m2.jpg" height="200px" width="200px"></a>
				</div>
				<div class="service-content">Action</p>		
				</div>
			</div>
		</div>
		
		<div class="services">
			<div class="ser-container">
			<div class="service-item">
				<div class="pic-size">
					<a href="dramamovie.php" target="_blank"><img src="img/m3.jpg" height="200px" width="200px"></a>
				</div>
				<div class="service-content">Drama</p>		
				</div>
			</div>
		</div>
<!--
		<div class="services">
			<div class="ser-container">
			<div class="service-item">
				<div class="pic-size">
					<a href="scifimovie.php" target="_blank"><img src="img/m4.jpg" height="200px" width="200px"></a>
				</div>
				<div class="service-content">Sci-fi</p>		
				</div>
			</div>
		</div>

		<div class="services">
			<div class="ser-container">
			<div class="service-item">
				<div class="pic-size">
					<a href="romancemovie.php" target="_blank"><img src="img/m5.jpg" height="200px" width="200px"></a>
				</div>
				<div class="service-content">Romance</p>		
				</div>
			</div>
		</div>

		<div class="services">
			<div class="ser-container">
			<div class="service-item">
				<div class="pic-size">
					<a href="comedymovie.php" target="_blank"><img src="img/m6.jpg" height="200px" width="200px"></a>
				</div>
				<div class="service-content">Comedy</p>		
				</div>
			</div>
		</div>
-->	
	</section><br>

	<?php
	include 'footer.php';
	?>

</body>
</html>