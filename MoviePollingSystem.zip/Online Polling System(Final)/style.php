<style type="text/css">
		
		{
			margin: 0;
			padding: 0;
		}

		body {
	background-image: url(Background4.jpg) width;

    color: #111;
    font: 17px Arial, Helvetica, sans-serif;
    line-height: 1.5em;
    margin: 0;

}

		ul li
		{
			list-style: none;
		}
		a
		{
			text-decoration: none;
		}

		div#jj
		{
			margin: auto;
			margin-top: 10%;
			width:320px; 
			border:1px solid #89bae0c9;
			padding: 10px;
			background: #89bae0c9;
			border-radius: 10px;
			height: 800px;
		}
		 input
		{
			margin-bottom: 11px;
			width: 99%;
			padding-top: 6px;
			padding-bottom: 6px;

		}
		.radio input
		{
			margin:0px;
		}

		.sUp
		{
			background: #89bae038;
			margin-bottom: 10px;
			text-align: center;
			
		}
		.link
		{
			align-content: center;
			color: blue;
		}
		/
		v1l{
    background-color: #4CAF50; 
    border: none;
    color: white;
    padding: 5px 10px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 2px;
    margin: 0px 0.5px;
    transition-duration: 0.4s;
    cursor: pointer;
}
.v1l {
    background-color: white; 
    color: black; 
    border: 2px solid #4CAF50;
    align-content: center;
}
.v1l:hover {
    background-color: #4CAF50;
    color: white;
}
		.link
		{
			color: #000;
			margin-left: 1px;
			margin-top: 2px;
		}
		
	</style>
	