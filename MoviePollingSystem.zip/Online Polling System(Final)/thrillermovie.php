<?php
session_start();
$email=$_SESSION['email'];
$db = mysqli_connect("localhost", "root", "", "onlinepollingsystem");
setcookie("name", "rifat@gmail.com", time()+10);
if(isset($_POST['v1l'])) {

	$email=$_SESSION['email'];
	$personalrating = $_POST['thrillerrating1'];
	$comment = $_POST['thrillercomment1'];
  	$sql = " INSERT INTO thriller(uemail,vote,personalrating,comment) VALUES('$email','gonegirl','$personalrating','$comment' )";
  	$verify=mysqli_query($db,$sql);
  	$sql = "UPDATE thriller SET gonegirl=gonegirl+1 WHERE vote='gonegirl' ";
  	$verify=mysqli_query($db,$sql);
}

elseif(isset($_POST['v2l'])) {

	$email=$_SESSION['email'];
	$personalrating = $_POST['thrillerrating2'];
	$comment = $_POST['thrillercomment2'];
  	$sql = " INSERT INTO thriller(uemail,vote,personalrating,comment) VALUES('$email','theprestige','$personalrating','$comment' )";
  	$verify=mysqli_query($db,$sql);
  	$sql = "UPDATE thriller SET theprestige=theprestige+1 WHERE vote='theprestige' ";
  	$verify=mysqli_query($db,$sql);
    	
}

elseif(isset($_POST['v3l'])) {

	$email=$_SESSION['email'];
	$personalrating = $_POST['thrillerrating3'];
	$comment = $_POST['thrillercomment3'];
  	$sql = " INSERT INTO thriller(uemail,vote,personalrating,comment) VALUES('$email','psycho','$personalrating','$comment' )";
  	$verify=mysqli_query($db,$sql);
  	$sql = "UPDATE thriller SET psycho=psycho+1 WHERE vote='psycho' ";
  	$verify=mysqli_query($db,$sql);
	
}

elseif(isset($_POST['v4l'])) {

	$email=$_SESSION['email'];
	$personalrating = $_POST['thrillerrating4'];
	$comment = $_POST['thrillercomment4'];
  	$sql = " INSERT INTO thriller(uemail,vote,personalrating,comment) VALUES('$email','shutterisland','$personalrating','$comment' )";
  	$verify=mysqli_query($db,$sql);
  	$sql = "UPDATE thriller SET shutterisland=shutterisland+1 WHERE vote='shutterisland' ";
  	$verify=mysqli_query($db,$sql);
	
}

elseif(isset($_POST['v5l'])) {

	$email=$_SESSION['email'];
	$personalrating = $_POST['thrillerrating5'];
	$comment = $_POST['thrillercomment5'];
  	$sql = " INSERT INTO thriller(uemail,vote,personalrating,comment) VALUES('$email','inception','$personalrating','$comment' )";
  	$verify=mysqli_query($db,$sql);
  	$sql = "UPDATE thriller SET inception=inception+1 WHERE vote='inception' ";
  	$verify=mysqli_query($db,$sql);	
	
}

elseif(isset($_POST['v6l'])) {

	$email=$_SESSION['email'];
	$personalrating = $_POST['thrillerrating6'];
	$comment = $_POST['thrillercomment6'];
  	$sql = " INSERT INTO thriller(uemail,vote,personalrating,comment) VALUES('$email','nocountryforoldmen','$personalrating','$comment' )";
  	$verify=mysqli_query($db,$sql);
  	$sql = "UPDATE thriller SET nocountryforoldmen=nocountryforoldmen+1 WHERE vote='nocountryforoldmen' ";
  	$verify=mysqli_query($db,$sql);	
	
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Thriller Movies</title>
	<link rel="stylesheet" href="css/thrillermovie.css">
</head>
<body>
<form method="POST" action="thrillermovie.php">
		<nav class="main-menu">
	 		<div class="logo"></div>
			 	<ul>
                    <li><a href="homepage.php">Home</a></li>
					<li><a class="current" href="#">Movies</a></li>
                    <li><a href="voterprofile.php">Profile</a></li>
					<li><a href="#contact">Contact</a></li>
				</ul>
	 	</nav>

	<section id="about" >
		<div class="kilibili">
			<div class="about-us">
				<img src="img/m1.jpg" height="330px" width="200px">
				<div class="about-us-left kilibili"><br>
				<h1>Gone Girl(2014)</h1><br>
					<h3>With his wife's disappearance having become the focus of an intense media circus,
						a man sees the spotlight turned on him when it's suspected that he may not be innocent.</h3><br>
					<h3>Director: David Fincher</h3>
					<div style="text-align: center;"><img src="img/yt1.png" width="40px" height="100%"><a href="https://youtu.be/2-_-1nJf8Vg"> Watch Trailer</a></div>
						<div class="list">
							<ul>
								
								<li>IMDB: 8.1</li>
								<li>Rotten Tomatoes: 87%</li>
								<li>Metacritic: 8.2</li>
								<li style="text-align: left;"><label style="text-align: center;">Personal Rating:<label>
									<input type="text" name="thrillerrating1" placeholder="Rate out of 10" ><br></li>
								<li style="text-align: left;"><label style="text-align: center;">Comment:<label>
									<input type="text" name="thrillercomment1"><br></li>
								<br>
							</ul>
						</div>
					<div style="text-align: center;"><input class="v1l" type="submit" name="v1l" value="Vote" required>
					</div>
			</div>
		</div>
	</section><hr><br>

	<section id="about" >
		<div class="kilibili">
			<div class="about-us">
				<img src="img/thrillermov2.jpg" height="330px" width="200px">
				<div class="about-us-left kilibili"><br>
				<h1>The Prestige(2006)</h1><br>
					<h3>Two friends and fellow magicians become bitter enemies after a sudden tragedy. As they devote themselves to this rivalry, 
						they make sacrifices that bring them fame but with terrible consequences.</h3><br>
					<h3>Director: Christopher Nolan</h3>
					<div style="text-align: center;"><img src="img/yt1.png" width="40px" height="100%"><a href="https://youtu.be/ijXruSzfGEc"> Watch Trailer</a></div>
						<div class="list">
							<ul>
								
								<li>IMDB: 8.1</li>
								<li>Rotten Tomatoes: 81%</li>
								<li>Metacritic: 70%</li>
								<li style="text-align: left;"><label style="text-align: center;">Personal Rating:<label>
									<input type="text" name="thrillerrating2" placeholder="Rate out of 10" ><br></li>
								<li style="text-align: left;"><label style="text-align: center;">Comment:<label>
									<input type="text" name="thrillercomment2"><br></li>
								<br>
							</ul>
						</div>
					<div style="text-align: center;"><input class="v1l" type="submit" name="v2l" value="Vote" required>
					</div>
			</div>
		</div>
	</section><hr><br>
	

	<section id="about" >
		<div class="kilibili">
			<div class="about-us">
				<img src="img/thrillermov3.jpg" height="330px" width="200px">
				<div class="about-us-left kilibili"><br>
				<h1>Phycho(1960)</h1><br>
					<h3>Marion disappears after stealing money from her employer. Her lover and sister try to find her 
						and end up reaching the infamous Bates Motel, where they meet Norman Bates.</h3><br>
					<h3>Director: Alfred Hitchcock</h3>
					<div style="text-align: center;"><img src="img/yt1.png" width="40px" height="100%"><a href="https://youtu.be/MJHsvfOOAYY"> Watch Trailer</a></div>
						<div class="list">
							<ul>
								
								<li>IMDB: 8.5</li>
								<li>Rotten Tomatoes: 96%</li>
								<li>Metacritic: 97%</li>
								<li style="text-align: left;"><label style="text-align: center;">Personal Rating:<label>
									<input type="text" name="thrillerrating3" placeholder="Rate out of 10" ><br></li>
								<li style="text-align: left;"><label style="text-align: center;">Comment:<label>
									<input type="text" name="thrillercomment3"><br></li>
								<br>
							</ul>
						</div>
					<div style="text-align: center;"><input class="v1l" type="submit" name="v3l" value="Vote" required>
					</div>
			</div>
		</div>
	</section><hr><br>

	<section id="about" >
		<div class="kilibili">
			<div class="about-us">
				<img src="img/thrillermov4.jpg" height="100%" width="200px">
				<div class="about-us-left kilibili"><br>
				<h1>Shutter Island(2010)</h1><br>
					<h3>Teddy Daniels and Chuck Aule, two US marshals, are sent to an asylum on a remote island in order to investigate the disappearance
						 of a patient, where Teddy uncovers a shocking truth about the place.</h3><br>
					<h3>Director: Martin Scorsese</h3>
					<div style="text-align: center;"><img src="img/yt1.png" width="40px" height="100%"><a href="https://youtu.be/qdPw9x9h5CY"> Watch Trailer</a></div>
						<div class="list">
							<ul>
								
								<li>IMDB: 8.2</li>
								<li>Rotten Tomatoes: 68%</li>
								<li>Metacritic: 63%</li>
								<li style="text-align: left;"><label style="text-align: center;">Personal Rating:<label>
									<input type="text" name="thrillerrating4" placeholder="Rate out of 10" ><br></li>
								<li style="text-align: left;"><label style="text-align: center;">Comment:<label>
									<input type="text" name="thrillercomment4"><br></li>
								<br>
							</ul>
						</div>
					<div style="text-align: center;"><input class="v1l" type="submit" name="v4l" value="Vote" required>
					</div>
			</div>
		</div>
	</section><hr><br>

	<section id="about" >
		<div class="kilibili">
			<div class="about-us">
				<img src="img/thrillermov5.jpg" height="100%" width="200px">
				<div class="about-us-left kilibili"><br>
				<h1>Inception(2010)</h1><br>
					<h3>Cobb steals information from his targets by entering their dreams. 
						Saito offers to wipe clean Cobb's criminal history as payment for performing an inception on his sick competitor's son.</h3><br>
					<h3>Director: Christopher Nolan</h3>
					<div style="text-align: center;"><img src="img/yt1.png" width="40px" height="100%"><a href="https://youtu.be/d3A3-zSOBT4"> Watch Trailer</a></div>
						<div class="list">
							<ul>
								
								<li>IMDB: 8.8</li>
								<li>Rotten Tomatoes: 87%</li>
								<li>Metacritic: 74%</li>
								<li style="text-align: left;"><label style="text-align: center;">Personal Rating:<label>
									<input type="text" name="thrillerrating5" placeholder="Rate out of 10" ><br></li>
								<li style="text-align: left;"><label style="text-align: center;">Comment:<label>
									<input type="text" name="thrillercomment5"><br></li>
								<br>
							</ul>
						</div>
					<div style="text-align: center;"><input class="v1l" type="submit" name="v5l" value="Vote" required>
					</div>
			</div>
		</div>
	</section><hr><br>
	

	<section id="about" >
		<div class="kilibili">
			<div class="about-us">
				<img src="img/thrillermov6.jpg" height="100%" width="200px">
				<div class="about-us-left kilibili"><br>
				<h1>No Country for Old Men(2007)</h1><br>
					<h3>A hunter's life takes a drastic turn when he discovers two million dollars while strolling through
						 the aftermath of a drug deal. He is then pursued by a psychopathic killer who wants the money.</h3><br>
					<h3>Director: David Fincher</h3>
					<div style="text-align: center;"><img src="img/yt1.png" width="40px" height="100%"><a href="https://youtu.be/aCjnUJjWb38"> Watch Trailer</a></div>
						<div class="list">
							<ul>
								
								<li>IMDB: 8.1</li>
								<li>Rotten Tomatoes: 93%</li>
								<li>Metacritic: 91%</li>
								<li style="text-align: left;"><label style="text-align: center;">Personal Rating:<label>
									<input type="text" name="thrillerrating6" placeholder="Rate out of 10" ><br></li>
								<li style="text-align: left;"><label style="text-align: center;">Comment:<label>
									<input type="text" name="thrillercomment6"><br></li>
								<br>
							</ul>
						</div>
					<div style="text-align: center;"><input class="v1l" type="submit" name="v6l" value="Vote" required>
					</div>
			</div>
		</div>
	</section><br>

</form>


<?php
	include 'footer.php';
?>
</body>
</html>