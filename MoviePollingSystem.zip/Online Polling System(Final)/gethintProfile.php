<?php

$a[] = "Afghanistan";
$a[] = "Australia";
$a[] = "Algeria";
$a[] = "Argentina";

$a[] = "Bangladesh";
$a[] = "Bahrain";
$a[] = "Barbados";
$a[] = "Belarus";

$a[] = "China";
$a[] = "Chili";
$a[] = "Cyba";
$a[] = "Colombia";

$a[] = "Denmark";
$a[] = "Djibouti";
$a[] = "Dominica";
$a[] = "Dominican Republic";

$a[] = "Ecuador";
$a[] = "Egypt";
$a[] = "Estonia";
$a[] = "Eritrea";


$a[] = "Fiji";
$a[] = "Finland";
$a[] = "France";

$a[] = "Germany";
$a[] = "Greece";
$a[] = "Ghana";
$a[] = "Guinea";

$a[] = "Haiti";
$h[] = "Holy See";
$h[] = "Hungary";
$h[] = "Honduras";

$a[] = "India";
$a[] = "Iran";
$a[] = "Iceland";
$a[] = "Italy";

$a[] = "Japan";
$a[] = "Jamaica";
$a[] = "Jordan";

$a[] = "Kenya";
$a[] = "Kiribati";
$a[] = "Kuwait";
$a[] = "Kyrgyzstan";

$a[] = "Laos";
$a[] = "Latvia";
$a[] = "Libya";
$a[] = "Lithuania";

$a[] = "Maldives";
$a[] = "Malaysia";
$a[] = "Mexico";
$a[] = "Malta";


$a[] = "Netherlands";
$a[] = "Nepal";
$a[] = "New Zealand";
$a[] = "Norway";

$a[] = "Oman";

$a[] = "Pakistan";
$a[] = "Peru";
$a[] = "Panama";
$a[] = "Philippines";

$a[] = "Qatar";

$a[] = "Russia";
$a[] = "Romania";
$a[] = "Rwanda";

$a[] = "Serbia";
$a[] = "Saudi Arabia";
$a[] = "Samoa";
$a[] = "Singapore";

$a[] = "Thailand";
$a[] = "Turkey";
$a[] = "Tunisia";
$a[] = "Tonga";


$a[] = "Uganda";
$a[] = "UK";
$a[] = "USA";
$a[] = "UAE";

$a[] = "Vanuatu";
$a[] = "Venezuela";
$a[] = "Vietnam";

$a[] = "West Indies";

$a[] = "Yemen";

$a[] = "Zimbabwe";
$a[] = "Zambia";



$q = $_REQUEST["q"];
$hint = "";

if ($q !== "") {
  $q = strtolower($q);
  $len=strlen($q);
  foreach($a as $name) {
    if (stristr($q, substr($name, 0, $len))) {
      if ($hint === "") {
        $hint = $name;
      } else {
        $hint .= ", $name";
      }
    }
  }
}
echo $hint === "" ? "no suggestion" : $hint;
?>