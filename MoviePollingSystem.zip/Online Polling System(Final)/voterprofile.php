<?php
include 'header.php';
?>

<style>
	.button
	{
		margin-left: 32%;
		padding-bottom: 20px;
	}

</style>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
<!--My Profile starts here-->
<body>
<h1>My Profile</h1><br>
<div class="table-responsive">
  <table class="table">
    <thead>
			<th>Name</th>
			<th>Address</th>
			<th>Phone</th>
			<th>Email</th>
			<th>Password</th>
			<th></th>
		</thead>
		<tbody>
			<?php 

				$db = mysqli_connect("localhost", "root", "", "onlinepollingsystem");
				session_start();
				$email = $_SESSION['email'];
				$selectq= " SELECT * FROM user WHERE email='$email' ";
			  	$query = mysqli_query($db, $selectq);
			  	while($result = mysqli_fetch_assoc($query))
			  	{
			?>		
			<tr>
				<td> <?php echo $result['name']; ?> </td>
				<td> <?php echo $result['address']; ?> </td>
				<td> <?php echo $result['phone']; ?> </td>
				<td> <?php echo $result['email']; ?> </td>
				<td> <?php echo $result['password']; ?> </td>
				<td> <a href="updateMyProfile.php?email=<?php echo $result['email']; ?>"><button type="button" class="btn btn-outline-info">Update</button></a> </td>
				<td> <a href="loginVoter.php"><button type="submit" class="btn btn-outline-info" name="logout">Logout</button></a> </td>
      <?php
              setcookie('identifier', 'Logged out', time()+5);
      ?>
			</tr>
		<?php 
			}
		 ?>	
		</tbody>
  </table><hr><br>
  <!--My Profile ends here-->

  <!--Movie Info starts here-->
  <h1>My Votes</h1><br>
<div class="table-responsive">
  <table class="table">
    <thead>
			<th>Genre</th>
			<th>Movie Name</th>
			<th>Personal Rating</th>
			<th>Comment</th>
			<th></th>
			<th></th>
			<th></th>
		</thead>
		<tbody>
			<?php 
				$db = mysqli_connect("localhost", "root", "", "onlinepollingsystem");
				$selectq= " SELECT * FROM thriller WHERE uemail='$email' ";
				$selectq2= " SELECT * FROM action1 WHERE uemail='$email' ";
				$selectq3= " SELECT * FROM drama WHERE uemail='$email' ";
				  $query = mysqli_query($db, $selectq);
				  $query2 = mysqli_query($db, $selectq2);
				  $query3 = mysqli_query($db, $selectq3);
			  	while($result = mysqli_fetch_assoc($query))
			  	{
					?>		
					<tr>
						<td> <?php echo "Thriller" ?> </td>
						<td> <?php echo $result['vote']; ?> </td>
						<td> <?php echo $result['personalrating']; ?> </td>
						<td> <?php echo $result['comment']; ?> </td>
					</tr>
					<?php 
				}
				while($result = mysqli_fetch_assoc($query2))
			  	{
					?>		
					<tr>
						<td> <?php echo "Action" ?> </td>
						<td> <?php echo $result['vote']; ?> </td>
						<td> <?php echo $result['personalrating']; ?> </td>
						<td> <?php echo $result['comment']; ?> </td>
					</tr>
					<?php 
				}
				while($result = mysqli_fetch_assoc($query3))
			  	{
					?>		
					<tr>
						<td> <?php echo "Drama" ?> </td>
						<td> <?php echo $result['vote']; ?> </td>
						<td> <?php echo $result['personalrating']; ?> </td>
						<td> <?php echo $result['comment']; ?> </td>
					</tr>
					<?php 
				}
		 ?>	
		</tbody>
  </table><hr><br>
  <!--Movie Info Ends here--> 
</div>
</body>

