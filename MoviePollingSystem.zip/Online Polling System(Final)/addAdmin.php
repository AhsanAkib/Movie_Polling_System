<?php 
        $db = mysqli_connect("localhost", "root", "","onlinepollingsystem");
        if(isset($_POST['signup'])) {
            session_start();
	        $email=$_SESSION['email'];
            $sql = "SELECT * FROM admin WHERE email='$email'";
            $verify = mysqli_query($db, $sql);
            if(mysqli_num_rows($verify) == 1){
                $newemail = $_POST['newemail'];
                $newpass = $_POST['newpass'];
                $sql1 = "INSERT INTO admin (email, password ) VALUES('$newemail', '$newpass')";
                mysqli_query($db, $sql1);
                echo "<script>
                        alert('Admin adding operation successful');
                    </script>";
            }
            else{
                echo "<script>
                        alert('Your password does not match. Please try again');
                    </script>";
            }
        }
        ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Add Admin</title>
    <link rel="stylesheet" href="css/work.css">
    <link rel="stylesheet" href="css/sidebar.css">
</head>
<body>
<script>
function showHint(str) {
  if (str.length == 0) {
    document.getElementById("txtHint").innerHTML = "";
    return;
  } else {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("txtHint").innerHTML = this.responseText;
      }
    };
    xmlhttp.open("GET", "ajax.php?q=" + str, true);
    xmlhttp.send();
  }
}
</script>
<form method="POST" action="addAdmin.php">
<div class="query"><marquee>Add more like you!</marquee></div>
<div id="sidebar" >
    <div class="toggle_button" onclick="toggleSidebar()">
        <span></span>
        <span></span>
        <span></span>
    </div>
    <ul>
        <li> <a href="AdminHome.php">Home</a></li>
        <li> <a href="addAdmin.php">Add Admin</a></li>
        <li> <a href="addMovie.php">Add Movie</a></li>
        <li> <a href="userinfo.php">User Information</a></li>
        <li> <a href="profile.php">Profile</a></li>
        <li> <a href="logout.php">Sign Out</a></li>
    </ul>
</div>

<script>
    function toggleSidebar(){
        document.getElementById("sidebar").classList.toggle('active');
    }
</script>
		<nav class="main-menu">
			 	<ul>
                 <li><a href="AdminHome.php">Home</a></li>
                    <li><a class="current" href="#">Add Admin</a></li>
                    <li><a href="addMovie.php" href="#">Add Movie</a></li>
                    <li><a href="userinfo.php" href="#">User</a></li>
                    <li><a href="profile.php" href="#">Profile</a></li>
                    <li><a href="logout.php" href="#">Sign out</a></li>
				</ul>
            </nav>
            <div>
                <section class="registerbox">
                    <h1>Sign Admin Up</h1>
                    <div class="textbox">
                        <i class="fa fa-user" aria-hidden="true"></i>
                        <input type="text" onkeyup="showHint(this.value)" placeholder="Enter Username" name="newemail">
                        <p class="sp">Don't pick: <span id="txtHint"></span></p>
        
                    </div>
                    <div class="textbox">
                        <i class="fa fa-lock" aria-hidden="true"></i>
                        <input type="password" placeholder="Enter Password" name="newpass" >
        
                    </div>
                        <input class="btn" type="submit" value="Sign Up" name="signup" id="signup" >
                </section>
                </div>
     
        
</form>



</body>
<html>