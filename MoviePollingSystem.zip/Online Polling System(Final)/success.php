
<!DOCTYPE html>
<html> 
<head>
   <title>Successfully Registered</title>
   
 </head>
 
 <body bgcolor='sky blue'>
 <?php
    session_start();
    if(isset($_SESSION['name']) && $_SESSION['phone'] && $_SESSION['address'] && $_SESSION['mail'] ) 
    {
        echo "<b>Welcome ".$_SESSION['name']." </b><br>";
        echo "You have been successfully registered in the webpage<br>";
         
        echo "Your number is: ".$_SESSION['phone']."<br>";
        echo "Your address is: ".$_SESSION['address']."<br>";
        echo "Your email is: ".$_SESSION['mail']."<br>";
        
    }
    else {
        header("location: loginVoter.php");
    }
?>

 </body>
 </html>