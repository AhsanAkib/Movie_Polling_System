<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Homepage</title>
	<link rel="stylesheet" href="css/homepage.css">
</head>
<body>
	<nav class="main-menu">
	 			<div class="logo">
	 			</div>
			 	<ul>
                    <li><a  href="homepage.php">Home</a></li>
					<li><a href="#movie">Movies</a></li>
					<li><a class="current" href="#">Profile</a></li>
					<li><a href="#contact">Contact</a></li>
				</ul>
	</nav>