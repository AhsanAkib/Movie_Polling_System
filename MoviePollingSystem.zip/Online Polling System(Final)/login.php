<?php 
echo $_COOKIE['identifier'];
$db = mysqli_connect("localhost", "root", "","onlinepollingsystem");
if(isset($_POST['login'])) {
    session_start();
    $email = $_POST['email'];
    $password = $_POST['pass'];
    $sql = "SELECT * FROM admin WHERE email='$email' AND password='$password'";
    $verify = mysqli_query($db, $sql);

    if(mysqli_num_rows($verify) == 1){
        $_SESSION['email'] = $email;
        if(strpos($email,"admin") !== false)
        {
            header("location: AdminHome.php");
        }
            else{
                echo "<script>
                        alert('Your email/password does not match. Please try again');
                    </script>";
            }
        }
    }
        ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Log In</title>
    <link rel="stylesheet" href="css/work.css">
    <link rel="stylesheet" href="css/sidebar.css">
</head>
<body>

<form method="POST" action="login.php">

            <div>
                <section class="registerbox">
                    <h1>Log In</h1>
                    <div class="textbox">
                        <i class="fa fa-user" aria-hidden="true"></i>
                        <input type="text" placeholder="Enter Email" name="email">
                        
        
                    </div>
                    <div class="textbox">
                        <i class="fa fa-lock" aria-hidden="true"></i>
                        <input type="password" placeholder="Enter Password" name="pass" >
        
                    </div>
                        <input class="btn" type="submit" value="Log In" name="login">
        
                </section>
            </div>
     
        
</form>



</body>
<html>