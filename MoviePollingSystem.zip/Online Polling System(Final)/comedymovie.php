<?php
$db = mysqli_connect("localhost", "root", "","pollingsystem");
if(isset($_POST['v1l'])) {
	session_start();
    
	$personalrating = $_POST['thrillerrating1'];
	$comment = $_POST['thrillercomment1'];
	$sql = "INSERT INTO `movie`(voteremail, name, dirname, imdb, rottentomatoes, metacritic, personalrating, comment, likedislike) VALUES ('rifat@gmail.com','Gone Girl','David Fincher','8.1','87%','8.2','$personalrating','$comment','Like')";
	mysqli_query($db, $sql);
}
elseif(isset($_POST['v1d'])) {
	session_start();
    
	$personalrating = $_POST['thrillerrating1'];
	$comment = $_POST['thrillercomment1'];
	$sql = "INSERT INTO `movie`(voteremail, name, dirname, imdb, rottentomatoes, metacritic, personalrating, comment, likedislike) VALUES ('rifat@gmail.com','Gone Girl','David Fincher','8.1','87%','8.2','$personalrating','$comment','Dislike')";
	mysqli_query($db, $sql);
	
}
elseif(isset($_POST['v2l'])) {
	session_start();
    
	$personalrating = $_POST['thrillerrating2'];
	$comment = $_POST['thrillercomment2'];
	$sql = "INSERT INTO `movie`(voteremail, name, dirname, imdb, rottentomatoes, metacritic, personalrating, comment, likedislike) VALUES ('rifat@gmail.com','The Prestige','Christopher Nolan','8.1','81%','70%','$personalrating','$comment','Like')";
	mysqli_query($db, $sql);
	
}
elseif(isset($_POST['v2d'])) {
	session_start();
    
	$personalrating = $_POST['thrillerrating2'];
	$comment = $_POST['thrillercomment2'];
	$sql = "INSERT INTO `movie`(voteremail, name, dirname, imdb, rottentomatoes, metacritic, personalrating, comment, likedislike) VALUES ('rifat@gmail.com','The Prestige','Christopher Nolan','8.1','81%','70%','$personalrating','$comment','Dislike')";
	mysqli_query($db, $sql);
	
}
elseif(isset($_POST['v3l'])) {
	session_start();
    
	$personalrating = $_POST['thrillerrating3'];
	$comment = $_POST['thrillercomment3'];
	$sql = "INSERT INTO `movie`(voteremail, name, dirname, imdb, rottentomatoes, metacritic, personalrating, comment, likedislike) VALUES ('rifat@gmail.com','Phycho','Alfred Hitchcock','8.5','96%','97%','$personalrating','$comment','Like')";
	mysqli_query($db, $sql);
	
}
elseif(isset($_POST['v3d'])) {
	session_start();
    
	$personalrating = $_POST['thrillerrating3'];
	$comment = $_POST['thrillercomment3'];
	$sql = "INSERT INTO `movie`(voteremail, name, dirname, imdb, rottentomatoes, metacritic, personalrating, comment, likedislike) VALUES ('rifat@gmail.com','Phycho','Alfred Hitchcock','8.5','96%','97%','$personalrating','$comment','Dislike')";
	mysqli_query($db, $sql);
	
}
elseif(isset($_POST['v4l'])) {
	session_start();
    
	$personalrating = $_POST['thrillerrating4'];
	$comment = $_POST['thrillercomment4'];
	$sql = "INSERT INTO `movie`(voteremail, name, dirname, imdb, rottentomatoes, metacritic, personalrating, comment, likedislike) VALUES ('rifat@gmail.com','Shutter Island','Martin Scorsese','8.2','68%','63','$personalrating','$comment','Like')";
	mysqli_query($db, $sql);
	
}
elseif(isset($_POST['v4d'])) {
	session_start();
    
	$personalrating = $_POST['thrillerrating4'];
	$comment = $_POST['thrillercomment4'];
	$sql = "INSERT INTO `movie`(voteremail, name, dirname, imdb, rottentomatoes, metacritic, personalrating, comment, likedislike) VALUES ('rifat@gmail.com','Shutter Island','Martin Scorsese','8.2','68%','63','$personalrating','$comment','Dislike')";
	mysqli_query($db, $sql);
	
}
elseif(isset($_POST['v5l'])) {
	session_start();
    
	$personalrating = $_POST['thrillerrating5'];
	$comment = $_POST['thrillercomment5'];
	$sql = "INSERT INTO `movie`(voteremail, name, dirname, imdb, rottentomatoes, metacritic, personalrating, comment, likedislike) VALUES ('rifat@gmail.com','Inception','Christopher Nolan','8.8','87%','74%','$personalrating','$comment','Like')";
	mysqli_query($db, $sql);
	
}
elseif(isset($_POST['v5d'])) {
	session_start();
    
	$personalrating = $_POST['thrillerrating5'];
	$comment = $_POST['thrillercomment5'];
	$sql = "INSERT INTO `movie`(voteremail, name, dirname, imdb, rottentomatoes, metacritic, personalrating, comment, likedislike) VALUES ('rifat@gmail.com','Inception','Christopher Nolan','8.8','87%','74%','$personalrating','$comment','Dislike')";
	mysqli_query($db, $sql);
	
}
elseif(isset($_POST['v6l'])) {
	session_start();
    
	$personalrating = $_POST['thrillerrating6'];
	$comment = $_POST['thrillercomment6'];
	$sql = "INSERT INTO `movie`(voteremail, name, dirname, imdb, rottentomatoes, metacritic, personalrating, comment, likedislike) VALUES ('rifat@gmail.com','No Country for Old Men','David Fincher','8.1','93%','91%','$personalrating','$comment','Like')";
	mysqli_query($db, $sql);
	
}
elseif(isset($_POST['v6d'])) {
	session_start();
    
	$personalrating = $_POST['thrillerrating6'];
	$comment = $_POST['thrillercomment6'];
	$sql = "INSERT INTO `movie`(voteremail, name, dirname, imdb, rottentomatoes, metacritic, personalrating, comment, likedislike) VALUES ('rifat@gmail.com','No Country for Old Men','David Fincher','8.1','93%','91%','$personalrating','$comment','Dislike')";
	mysqli_query($db, $sql);
	
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Thriller Movies</title>
	<link rel="stylesheet" href="css/thrillermovie.css">
</head>
<body>
<form method="POST" action="comedymovie.php">
	<div class="query"> </div>
		<nav class="main-menu">
	 		<div class="logo"></div>
			 	<ul>
                    <li><a href="homepage.php">Home</a></li>
					<li><a class="current" href="#">Movies</a></li>
                    <li><a href="#">TV-Series</a></li>
					<li><a href="#">Contact</a></li>
				</ul>
	 	</nav>

	<section id="about" >
		<div class="kilibili">
			<div class="about-us">
				<img src="img/m1.jpg" height="330px" width="200px">
				<div class="about-us-left kilibili"><br>
				<h1>Gone Girl(2014)</h1><br>
					<h3>With his wife's disappearance having become the focus of an intense media circus,
						a man sees the spotlight turned on him when it's suspected that he may not be innocent.</h3><br>
					<h3>Director: David Fincher</h3>
					<div style="text-align: center;"><img src="img/yt1.png" width="40px" height="100%"><a href="https://youtu.be/2-_-1nJf8Vg"> Watch Trailer</a></div>
						<div class="list">
							<ul>
								
								<li>IMDB: 8.1</li>
								<li>Rotten Tomatoes: 87%</li>
								<li>Metacritic: 8.2</li>
								<li style="text-align: left;"><label style="text-align: center;">Personal Rating:<label>
									<input type="text" name="thrillerrating1" placeholder="Rate out of 10" ><br></li>
								<li style="text-align: left;"><label style="text-align: center;">Comment:<label>
									<input type="text" name="thrillercomment1"><br></li>
								<br>
							</ul>
						</div>
					<div style="text-align: center;"><input class="v1l" type="submit" name="v1l" value="Like" required>
					<input class="v1d" type="submit" name="v1d" value="Dislike" style="text-align: center" required ></div>
			</div>
		</div>
	</section><hr><br>

	<section id="about" >
		<div class="kilibili">
			<div class="about-us">
				<img src="img/thrillermov2.jpg" height="330px" width="200px">
				<div class="about-us-left kilibili"><br>
				<h1>The Prestige(2006)</h1><br>
					<h3>Two friends and fellow magicians become bitter enemies after a sudden tragedy. As they devote themselves to this rivalry, 
						they make sacrifices that bring them fame but with terrible consequences.</h3><br>
					<h3>Director: Christopher Nolan</h3>
					<div style="text-align: center;"><img src="img/yt1.png" width="40px" height="100%"><a href="https://youtu.be/ijXruSzfGEc"> Watch Trailer</a></div>
						<div class="list">
							<ul>
								
								<li>IMDB: 8.1</li>
								<li>Rotten Tomatoes: 81%</li>
								<li>Metacritic: 70%</li>
								<li style="text-align: left;"><label style="text-align: center;">Personal Rating:<label>
									<input type="text" name="thrillerrating2" placeholder="Rate out of 10" ><br></li>
								<li style="text-align: left;"><label style="text-align: center;">Comment:<label>
									<input type="text" name="thrillercomment2"><br></li>
								<br>
							</ul>
						</div>
					<div style="text-align: center;"><input class="v1l" type="submit" name="v2l" value="Like" required>
					<input class="v1d" type="submit" name="v2d" value="Dislike" style="text-align: center" required ></div>
			</div>
		</div>
	</section><hr><br>
	

	<section id="about" >
		<div class="kilibili">
			<div class="about-us">
				<img src="img/thrillermov3.jpg" height="330px" width="200px">
				<div class="about-us-left kilibili"><br>
				<h1>Phycho(1960)</h1><br>
					<h3>Marion disappears after stealing money from her employer. Her lover and sister try to find her 
						and end up reaching the infamous Bates Motel, where they meet Norman Bates.</h3><br>
					<h3>Director: Alfred Hitchcock</h3>
					<div style="text-align: center;"><img src="img/yt1.png" width="40px" height="100%"><a href="https://youtu.be/MJHsvfOOAYY"> Watch Trailer</a></div>
						<div class="list">
							<ul>
								
								<li>IMDB: 8.5</li>
								<li>Rotten Tomatoes: 96%</li>
								<li>Metacritic: 97%</li>
								<li style="text-align: left;"><label style="text-align: center;">Personal Rating:<label>
									<input type="text" name="thrillerrating3" placeholder="Rate out of 10" ><br></li>
								<li style="text-align: left;"><label style="text-align: center;">Comment:<label>
									<input type="text" name="thrillercomment3"><br></li>
								<br>
							</ul>
						</div>
					<div style="text-align: center;"><input class="v1l" type="submit" name="v3l" value="Like" required>
					<input class="v1d" type="submit" name="v3d" value="Dislike" style="text-align: center" required ></div>
			</div>
		</div>
	</section><hr><br>

	<section id="about" >
		<div class="kilibili">
			<div class="about-us">
				<img src="img/thrillermov4.jpg" height="100%" width="200px">
				<div class="about-us-left kilibili"><br>
				<h1>Shutter Island(2010)</h1><br>
					<h3>Teddy Daniels and Chuck Aule, two US marshals, are sent to an asylum on a remote island in order to investigate the disappearance
						 of a patient, where Teddy uncovers a shocking truth about the place.</h3><br>
					<h3>Director: Martin Scorsese</h3>
					<div style="text-align: center;"><img src="img/yt1.png" width="40px" height="100%"><a href="https://youtu.be/qdPw9x9h5CY"> Watch Trailer</a></div>
						<div class="list">
							<ul>
								
								<li>IMDB: 8.2</li>
								<li>Rotten Tomatoes: 68%</li>
								<li>Metacritic: 63%</li>
								<li style="text-align: left;"><label style="text-align: center;">Personal Rating:<label>
									<input type="text" name="thrillerrating4" placeholder="Rate out of 10" ><br></li>
								<li style="text-align: left;"><label style="text-align: center;">Comment:<label>
									<input type="text" name="thrillercomment4"><br></li>
								<br>
							</ul>
						</div>
					<div style="text-align: center;"><input class="v1l" type="submit" name="v4l" value="Like" required>
					<input class="v1d" type="submit" name="v4d" value="Dislike" style="text-align: center" required ></div>
			</div>
		</div>
	</section><hr><br>

	<section id="about" >
		<div class="kilibili">
			<div class="about-us">
				<img src="img/thrillermov5.jpg" height="100%" width="200px">
				<div class="about-us-left kilibili"><br>
				<h1>Inception(2010)</h1><br>
					<h3>Cobb steals information from his targets by entering their dreams. 
						Saito offers to wipe clean Cobb's criminal history as payment for performing an inception on his sick competitor's son.</h3><br>
					<h3>Director: Christopher Nolan</h3>
					<div style="text-align: center;"><img src="img/yt1.png" width="40px" height="100%"><a href="https://youtu.be/d3A3-zSOBT4"> Watch Trailer</a></div>
						<div class="list">
							<ul>
								
								<li>IMDB: 8.8</li>
								<li>Rotten Tomatoes: 87%</li>
								<li>Metacritic: 74%</li>
								<li style="text-align: left;"><label style="text-align: center;">Personal Rating:<label>
									<input type="text" name="thrillerrating5" placeholder="Rate out of 10" ><br></li>
								<li style="text-align: left;"><label style="text-align: center;">Comment:<label>
									<input type="text" name="thrillercomment5"><br></li>
								<br>
							</ul>
						</div>
					<div style="text-align: center;"><input class="v1l" type="submit" name="v5l" value="Like" required>
					<input class="v1d" type="submit" name="v5d" value="Dislike" style="text-align: center" required ></div>
			</div>
		</div>
	</section><hr><br>
	

	<section id="about" >
		<div class="kilibili">
			<div class="about-us">
				<img src="img/thrillermov6.jpg" height="100%" width="200px">
				<div class="about-us-left kilibili"><br>
				<h1>No Country for Old Men(2007)</h1><br>
					<h3>A hunter's life takes a drastic turn when he discovers two million dollars while strolling through
						 the aftermath of a drug deal. He is then pursued by a psychopathic killer who wants the money.</h3><br>
					<h3>Director: David Fincher</h3>
					<div style="text-align: center;"><img src="img/yt1.png" width="40px" height="100%"><a href="https://youtu.be/aCjnUJjWb38"> Watch Trailer</a></div>
						<div class="list">
							<ul>
								
								<li>IMDB: 8.1</li>
								<li>Rotten Tomatoes: 93%</li>
								<li>Metacritic: 91%</li>
								<li style="text-align: left;"><label style="text-align: center;">Personal Rating:<label>
									<input type="text" name="thrillerrating6" placeholder="Rate out of 10" ><br></li>
								<li style="text-align: left;"><label style="text-align: center;">Comment:<label>
									<input type="text" name="thrillercomment6"><br></li>
								<br>
							</ul>
						</div>
					<div style="text-align: center;"><input class="v1l" type="submit" name="v6l" value="Like" required>
					<input class="v1d" type="submit" name="v6d" value="Dislike" style="text-align: center" required ></div>
			</div>
		</div>
	</section><br>
					<!--          <div style="text-align: center;"><input class="v1l" type="submit" name="logout" value="Logout" >
					</div>        -->

</form>


			<div class="footer-bottom">
				<hr>
				<p>© 2020 StreamZ Corporation</p>
			</div>
		</div>
	</footer>


</body>
</html>