<?php
session_start();
$email=$_SESSION['email'];
$db = mysqli_connect("localhost", "root", "", "onlinepollingsystem");
//setcookie("name", "rifat@gmail.com", time()+120);
if(isset($_POST['v1l'])) {

	$email=$_SESSION['email'];
	$personalrating = $_POST['thrillerrating1'];
	$comment = $_POST['thrillercomment1'];
  	$sql = " INSERT INTO action1(uemail,vote,personalrating,comment) VALUES('$email','thedarkknight','$personalrating','$comment' )";
  	$verify=mysqli_query($db,$sql);
  	$sql = "UPDATE action1 SET thedarkknight=thedarkknight+1 WHERE vote='thedarkknight' ";
  	$verify=mysqli_query($db,$sql);
 	//echo"<script>
	// 	alert('Voted Sucessfully!');
 	//</script>";
}

elseif(isset($_POST['v2l'])) {

	$email=$_SESSION['email'];
	$personalrating = $_POST['thrillerrating2'];
	$comment = $_POST['thrillercomment2'];
  	$sql = " INSERT INTO action1(uemail,vote,personalrating,comment) VALUES('$email','spectre','$personalrating','$comment' )";
  	$verify=mysqli_query($db,$sql);
  	$sql = "UPDATE action1 SET spectre=spectre+1 WHERE vote='spectre' ";
  	$verify=mysqli_query($db,$sql);
    	
}

elseif(isset($_POST['v3l'])) {

	$email=$_SESSION['email'];
	$personalrating = $_POST['thrillerrating3'];
	$comment = $_POST['thrillercomment3'];
  	$sql = " INSERT INTO action1(uemail,vote,personalrating,comment) VALUES('$email','madmaxfuryroad','$personalrating','$comment' )";
  	$verify=mysqli_query($db,$sql);
  	$sql = "UPDATE action1 SET madmaxfuryroad=madmaxfuryroad+1 WHERE vote='madmaxfuryroad' ";
  	$verify=mysqli_query($db,$sql);
	
}

elseif(isset($_POST['v4l'])) {

	$email=$_SESSION['email'];
	$personalrating = $_POST['thrillerrating4'];
	$comment = $_POST['thrillercomment4'];
  	$sql = " INSERT INTO action1(uemail,vote,personalrating,comment) VALUES('$email','thematrix','$personalrating','$comment' )";
  	$verify=mysqli_query($db,$sql);
  	$sql = "UPDATE action1 SET thematrix=thematrix+1 WHERE vote='thematrix' ";
  	$verify=mysqli_query($db,$sql);
	
}

elseif(isset($_POST['v5l'])) {

	$email=$_SESSION['email'];
	$personalrating = $_POST['thrillerrating5'];
	$comment = $_POST['thrillercomment5'];
  	$sql = " INSERT INTO action1(uemail,vote,personalrating,comment) VALUES('$email','fastfive','$personalrating','$comment' )";
  	$verify=mysqli_query($db,$sql);
  	$sql = "UPDATE action1 SET fastfive=fastfive+1 WHERE vote='fastfive' ";
  	$verify=mysqli_query($db,$sql);	
	
}

elseif(isset($_POST['v6l'])) {

	$email=$_SESSION['email'];
	$personalrating = $_POST['thrillerrating6'];
	$comment = $_POST['thrillercomment6'];
  	$sql = " INSERT INTO action1(uemail,vote,personalrating,comment) VALUES('$email','johnwick','$personalrating','$comment' )";
  	$verify=mysqli_query($db,$sql);
  	$sql = "UPDATE action1 SET johnwick=johnwick+1 WHERE vote='johnwick' ";
  	$verify=mysqli_query($db,$sql);	
	
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Action Movies</title>
	<link rel="stylesheet" href="css/thrillermovie.css">
</head>
<body>
<form method="POST" action="actionmovie.php">
		<nav class="main-menu">
	 		<div class="logo"></div>
			 	<ul>
                    <li><a href="homepage.php">Home</a></li>
					<li><a class="current" href="#">Movies</a></li>
                    <li><a href="voterprofile.php">Profile</a></li>
					<li><a href="#contact">Contact</a></li>
				</ul>
	 	</nav>

	<section id="about" >
		<div class="kilibili">
			<div class="about-us">
				<img src="img/actionmov1.jpg" height="330px" width="200px">
				<div class="about-us-left kilibili"><br>
				<h1>The Dark Knight(2008)</h1><br>
					<h3>After Gordon, Dent and Batman begin an assault on Gotham's organised crime, the mobs hire the Joker,
						 a psychopathic criminal mastermind who offers to kill Batman and bring the city to its knees.</h3><br>
					<h3>Director: Christopher Nolan</h3>
					<div style="text-align: center;"><img src="img/yt1.png" width="40px" height="100%"><a href="https://youtu.be/kmJLuwP3MbY"> Watch Trailer</a></div>
						<div class="list">
							<ul>
								
								<li>IMDB: 9.0</li>
								<li>Rotten Tomatoes: 94%</li>
								<li>Metacritic: 84%</li>
								<li style="text-align: left;"><label style="text-align: center;">Personal Rating:<label>
									<input type="text" name="thrillerrating1" placeholder="Rate out of 10" ><br></li>
								<li style="text-align: left;"><label style="text-align: center;">Comment:<label>
									<input type="text" name="thrillercomment1"><br></li>
								<br>
							</ul>
						</div>
					<div style="text-align: center;"><input class="v1l" type="submit" name="v1l" value="Vote" required>
					</div>
			</div>
		</div>
	</section><hr><br>

	<section id="about" >
		<div class="kilibili">
			<div class="about-us">
				<img src="img/actionmov2.jpg" height="330px" width="200px">
				<div class="about-us-left kilibili"><br>
				<h1>Spectre(2015)</h1><br>
					<h3>James Bond receives an obscure message from M about a sinister organisation,
						 'SPECTRE'. With the help of Madeleine, he uncovers the conspiracy, only to face an ugly truth.</h3><br>
					<h3>Director: Sam Mendes</h3>
					<div style="text-align: center;"><img src="img/yt1.png" width="40px" height="100%"><a href="https://youtu.be/LTDaET-JweU"> Watch Trailer</a></div>
						<div class="list">
							<ul>
								
								<li>IMDB: 6.8</li>
								<li>Rotten Tomatoes: 63%</li>
								<li>Metacritic: 60%</li>
								<li style="text-align: left;"><label style="text-align: center;">Personal Rating:<label>
									<input type="text" name="thrillerrating2" placeholder="Rate out of 10" ><br></li>
								<li style="text-align: left;"><label style="text-align: center;">Comment:<label>
									<input type="text" name="thrillercomment2"><br></li>
								<br>
							</ul>
						</div>
					<div style="text-align: center;"><input class="v1l" type="submit" name="v2l" value="Vote" required>
					</div>
			</div>
		</div>
	</section><hr><br>
	

	<section id="about" >
		<div class="kilibili">
			<div class="about-us">
				<img src="img/actionmov3.jpg" height="330px" width="200px">
				<div class="about-us-left kilibili"><br>
				<h1>Mad Max: Fury Road(2015)</h1><br>
					<h3>Years after the collapse of civilization, the tyrannical Immortan Joe enslaves apocalypse survivors inside the desert fortress the Citadel. When the warrior Imperator Furiosa (Charlize Theron) leads
						 the despot's five wives in a daring escape, she forges an alliance with Max Rockatansky (Tom Hardy)</h3><br>
					<h3>Director: George Miller</h3>
					<div style="text-align: center;"><img src="img/yt1.png" width="40px" height="100%"><a href="https://youtu.be/hEJnMQG9ev8"> Watch Trailer</a></div>
						<div class="list">
							<ul>
								
								<li>IMDB: 8.1</li>
								<li>Rotten Tomatoes: 97%</li>
								<li>Metacritic: 90%</li>
								<li style="text-align: left;"><label style="text-align: center;">Personal Rating:<label>
									<input type="text" name="thrillerrating3" placeholder="Rate out of 10" ><br></li>
								<li style="text-align: left;"><label style="text-align: center;">Comment:<label>
									<input type="text" name="thrillercomment3"><br></li>
								<br>
							</ul>
						</div>
					<div style="text-align: center;"><input class="v1l" type="submit" name="v3l" value="Vote" required>
					</div>
			</div>
		</div>
	</section><hr><br>

	<section id="about" >
		<div class="kilibili">
			<div class="about-us">
				<img src="img/actionmov4.jpg" height="100%" width="200px">
				<div class="about-us-left kilibili"><br>
				<h1>The Matrix(1999)</h1><br>
					<h3>Thomas Anderson, a computer programmer, is led to fight an underground war
						 against powerful computers who have constructed his entire reality with a system called the Matrix.</h3><br>
					<h3>Director: Lilly Wachowski</h3>
					<div style="text-align: center;"><img src="img/yt1.png" width="40px" height="100%"><a href="https://youtu.be/vKQi3bBA1y8"> Watch Trailer</a></div>
						<div class="list">
							<ul>
								
								<li>IMDB: 8.7</li>
								<li>Rotten Tomatoes: 88%</li>
								<li>Metacritic: 93%</li>
								<li style="text-align: left;"><label style="text-align: center;">Personal Rating:<label>
									<input type="text" name="thrillerrating4" placeholder="Rate out of 10" ><br></li>
								<li style="text-align: left;"><label style="text-align: center;">Comment:<label>
									<input type="text" name="thrillercomment4"><br></li>
								<br>
							</ul>
						</div>
					<div style="text-align: center;"><input class="v1l" type="submit" name="v4l" value="Vote" required>
					</div>
			</div>
		</div>
	</section><hr><br>

	<section id="about" >
		<div class="kilibili">
			<div class="about-us">
				<img src="img/actionmov5.jpg" height="100%" width="200px">
				<div class="about-us-left kilibili"><br>
				<h1>Fast Five(2011)</h1><br>
					<h3>Dom and Brian travel from one country to another trying to throw the authorities off their scent.
						 Now they have to bring their team together one more time while being chased by a federal agent.</h3><br>
					<h3>Director: Justin Lin</h3>
					<div style="text-align: center;"><img src="img/yt1.png" width="40px" height="100%"><a href="https://youtu.be/mw2AqdB5EVA"> Watch Trailer</a></div>
						<div class="list">
							<ul>
								
								<li>IMDB: 7.3</li>
								<li>Rotten Tomatoes: 77%</li>
								<li>Metacritic: 66%</li>
								<li style="text-align: left;"><label style="text-align: center;">Personal Rating:<label>
									<input type="text" name="thrillerrating5" placeholder="Rate out of 10" ><br></li>
								<li style="text-align: left;"><label style="text-align: center;">Comment:<label>
									<input type="text" name="thrillercomment5"><br></li>
								<br>
							</ul>
						</div>
					<div style="text-align: center;"><input class="v1l" type="submit" name="v5l" value="Vote" required>
					</div>
			</div>
		</div>
	</section><hr><br>
	

	<section id="about" >
		<div class="kilibili">
			<div class="about-us">
				<img src="img/actionmov6.jpg" height="100%" width="200px">
				<div class="about-us-left kilibili"><br>
				<h1>John Wick (2014)</h1><br>
					<h3>John Wick is an American neo-noir action-thriller media franchise created by screenwriter
						 Derek Kolstad and owned by Summit Entertainment. Keanu Reeves plays John Wick, a retired hitman seeking vengeance
						 for the killing of the dog given to him by his recently deceased wife.</h3><br>
					<h3>Director: Chad Stahelski</h3>
					<div style="text-align: center;"><img src="img/yt1.png" width="40px" height="100%"><a href="https://youtu.be/2AUmvWm5ZDQ"> Watch Trailer</a></div>
						<div class="list">
							<ul>
								
								<li>IMDB: 7.4</li>
								<li>Rotten Tomatoes: 87%</li>
								<li>Metacritic: 8.1</li>
								<li style="text-align: left;"><label style="text-align: center;">Personal Rating:<label>
									<input type="text" name="thrillerrating6" placeholder="Rate out of 10" ><br></li>
								<li style="text-align: left;"><label style="text-align: center;">Comment:<label>
									<input type="text" name="thrillercomment6"><br></li>
								<br>
							</ul>
						</div>
					<div style="text-align: center;"><input class="v1l" type="submit" name="v6l" value="Vote" required>
					</div>
			</div>
		</div>
	</section><br>
<!--
	<hr>
	<div style="text-align: center;"><input class="v1l" type="submit" name="logout" value="Logout" >
	</div>       
-->
</form>


<?php
	include 'footer.php';
?>
</body>
</html>