-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 26, 2020 at 04:54 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlinepollingsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `action1`
--

CREATE TABLE `action1` (
  `uid` int(11) NOT NULL,
  `uemail` varchar(100) NOT NULL,
  `vote` varchar(100) NOT NULL,
  `personalrating` float NOT NULL,
  `comment` varchar(100) NOT NULL,
  `thedarkknight` int(11) NOT NULL,
  `spectre` int(11) NOT NULL,
  `madmaxfuryroad` int(11) NOT NULL,
  `thematrix` int(11) NOT NULL,
  `fastfive` int(11) NOT NULL,
  `johnwick` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `action1`
--

INSERT INTO `action1` (`uid`, `uemail`, `vote`, `personalrating`, `comment`, `thedarkknight`, `spectre`, `madmaxfuryroad`, `thematrix`, `fastfive`, `johnwick`) VALUES
(1, 'rifat@gmail.com', 'thedarkknight', 10, 'Best1', 1, 0, 0, 0, 0, 0),
(2, 'rifat@gmail.com', 'spectre', 9, 'Best2', 0, 1, 0, 0, 0, 0),
(3, 'rifat@gmail.com', 'madmaxfuryroad', 8, 'Best3', 0, 0, 1, 0, 0, 0),
(4, 'rifat@gmail.com', 'thematrix', 7, 'Best4', 0, 0, 0, 2, 0, 0),
(5, 'rifat@gmail.com', 'fastfive', 6, 'Best5', 0, 0, 0, 0, 1, 0),
(6, 'rifat@gmail.com', 'johnwick', 5, 'Best6', 0, 0, 0, 0, 0, 1),
(7, 'rifat@gmail.com', 'thematrix', 9.6, 'Neo', 0, 0, 0, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `drama`
--

CREATE TABLE `drama` (
  `uid` int(11) NOT NULL,
  `uemail` varchar(100) NOT NULL,
  `vote` varchar(100) NOT NULL,
  `personalrating` float NOT NULL,
  `comment` varchar(100) NOT NULL,
  `thegodfather` int(11) NOT NULL,
  `angrymen` int(11) NOT NULL,
  `slist` int(11) NOT NULL,
  `spotlight` int(11) NOT NULL,
  `taxidriver` int(11) NOT NULL,
  `theirishmen` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `drama`
--

INSERT INTO `drama` (`uid`, `uemail`, `vote`, `personalrating`, `comment`, `thegodfather`, `angrymen`, `slist`, `spotlight`, `taxidriver`, `theirishmen`) VALUES
(0, 'rifat@gmail.com', 'thegodfather', 10, 'Best10', 1, 0, 0, 0, 0, 0),
(0, 'rifat@gmail.com', 'angrymen', 9, 'Best9', 0, 1, 0, 0, 0, 0),
(0, 'rifat@gmail.com', 'slist', 8, 'Best8', 0, 0, 1, 0, 0, 0),
(0, 'rifat@gmail.com', 'spotlight', 7, 'Best7', 0, 0, 0, 1, 0, 0),
(0, 'rifat@gmail.com', 'taxidriver', 6, 'Best6', 0, 0, 0, 0, 2, 0),
(0, 'rifat@gmail.com', 'taxidriver', 5, 'Best5', 0, 0, 0, 0, 1, 0),
(0, 'rifat@gmail.com', 'theirishmen', 4, 'Best4', 0, 0, 0, 0, 0, 3),
(0, 'rifat@gmail.com', 'theirishmen', 4, 'Best4', 0, 0, 0, 0, 0, 2),
(0, 'rifat@gmail.com', 'theirishmen', 4, 'Best4', 0, 0, 0, 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `thriller`
--

CREATE TABLE `thriller` (
  `uid` int(11) NOT NULL,
  `uemail` varchar(100) NOT NULL,
  `vote` varchar(100) NOT NULL,
  `personalrating` float NOT NULL,
  `comment` varchar(100) NOT NULL,
  `gonegirl` int(11) NOT NULL,
  `theprestige` int(11) NOT NULL,
  `psycho` int(11) NOT NULL,
  `shutterisland` int(11) NOT NULL,
  `inception` int(11) NOT NULL,
  `nocountryforoldmen` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `thriller`
--

INSERT INTO `thriller` (`uid`, `uemail`, `vote`, `personalrating`, `comment`, `gonegirl`, `theprestige`, `psycho`, `shutterisland`, `inception`, `nocountryforoldmen`) VALUES
(1, 'rifat@gmail.com', 'gonegirl', 9, '0', 4, 0, 0, 0, 0, 0),
(2, 'rifat@gmail.com', 'gonegirl', 0, '0', 3, 0, 0, 0, 0, 0),
(3, 'rifat@gmail.com', 'gonegirl', 0, '0', 2, 0, 0, 0, 0, 0),
(4, 'HRrifat@gmail.com', 'gonegirl', 10, '0', 1, 0, 0, 0, 0, 0),
(5, 'HRrifat@gmail.com', 'theprestige', 9, '0', 0, 1, 0, 0, 0, 0),
(6, 'HRrifat@gmail.com', 'psycho', 8, '0', 0, 0, 1, 0, 0, 0),
(7, 'HRrifat@gmail.com', 'shutterisland', 9, '0', 0, 0, 0, 1, 0, 0),
(8, 'HRrifat@gmail.com', 'inception', 8, '0', 0, 0, 0, 0, 2, 0),
(9, 'HRrifat@gmail.com', 'nocountryforoldmen', 7, '0', 0, 0, 0, 0, 0, 2),
(10, 'HRrifat@gmail.com', 'nocountryforoldmen', 8, '0', 0, 0, 0, 0, 0, 1),
(11, 'HRrifat@gmail.com', 'inception', 9.5, 'Mindblowing!', 0, 0, 0, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password`, `address`, `phone`) VALUES
(4, 'Rifaaat', 'rifat2@gmail.com', '1234', 'UK', '0101'),
(13, 'Rifat', 'rifat@gmail.com', 'pass', 'Bangladesh', '01521108947');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `action1`
--
ALTER TABLE `action1`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `thriller`
--
ALTER TABLE `thriller`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UC_Members` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `action1`
--
ALTER TABLE `action1`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `thriller`
--
ALTER TABLE `thriller`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
