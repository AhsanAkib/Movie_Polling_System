<?php
session_start();
$email=$_SESSION['email'];
$db = mysqli_connect("localhost", "root", "", "onlinepollingsystem");
//setcookie("name", "rifat@gmail.com", time()+120);
if(isset($_POST['v1l'])) {

	$email=$_SESSION['email'];
	$personalrating = $_POST['thrillerrating1'];
	$comment = $_POST['thrillercomment1'];
  	$sql = " INSERT INTO drama(uemail,vote,personalrating,comment) VALUES('$email','thegodfather','$personalrating','$comment' )";
  	$verify=mysqli_query($db,$sql);
  	$sql = "UPDATE drama SET thegodfather=thegodfather+1 WHERE vote='thegodfather' ";
  	$verify=mysqli_query($db,$sql);
 	//echo"<script>
	// 	alert('Voted Sucessfully!');
 	//</script>";
}

elseif(isset($_POST['v2l'])) {

	$email=$_SESSION['email'];
	$personalrating = $_POST['thrillerrating2'];
	$comment = $_POST['thrillercomment2'];
  	$sql = " INSERT INTO drama(uemail,vote,personalrating,comment) VALUES('$email','angrymen','$personalrating','$comment' )";
  	$verify=mysqli_query($db,$sql);
  	$sql = "UPDATE drama SET angrymen=angrymen+1 WHERE vote='angrymen' ";
  	$verify=mysqli_query($db,$sql);
    	
}

elseif(isset($_POST['v3l'])) {

	$email=$_SESSION['email'];
	$personalrating = $_POST['thrillerrating3'];
	$comment = $_POST['thrillercomment3'];
  	$sql = " INSERT INTO drama(uemail,vote,personalrating,comment) VALUES('$email','slist','$personalrating','$comment' )";
  	$verify=mysqli_query($db,$sql);
  	$sql = "UPDATE drama SET slist=slist+1 WHERE vote='slist' ";
  	$verify=mysqli_query($db,$sql);
	
}

elseif(isset($_POST['v4l'])) {

	$email=$_SESSION['email'];
	$personalrating = $_POST['thrillerrating4'];
	$comment = $_POST['thrillercomment4'];
  	$sql = " INSERT INTO drama(uemail,vote,personalrating,comment) VALUES('$email','spotlight','$personalrating','$comment' )";
  	$verify=mysqli_query($db,$sql);
  	$sql = "UPDATE drama SET spotlight=spotlight+1 WHERE vote='spotlight' ";
  	$verify=mysqli_query($db,$sql);
	
}

elseif(isset($_POST['v5l'])) {

	$email=$_SESSION['email'];
	$personalrating = $_POST['thrillerrating5'];
	$comment = $_POST['thrillercomment5'];
  	$sql = " INSERT INTO drama(uemail,vote,personalrating,comment) VALUES('$email','taxidriver','$personalrating','$comment' )";
  	$verify=mysqli_query($db,$sql);
  	$sql = "UPDATE drama SET taxidriver=taxidriver+1 WHERE vote='taxidriver' ";
  	$verify=mysqli_query($db,$sql);	
	
}

elseif(isset($_POST['v6l'])) {

	$email=$_SESSION['email'];
	$personalrating = $_POST['thrillerrating6'];
	$comment = $_POST['thrillercomment6'];
  	$sql = " INSERT INTO drama(uemail,vote,personalrating,comment) VALUES('$email','theirishmen','$personalrating','$comment' )";
  	$verify=mysqli_query($db,$sql);
  	$sql = "UPDATE drama SET theirishmen=theirishmen+1 WHERE vote='theirishmen' ";
  	$verify=mysqli_query($db,$sql);	
	
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Drama Movies</title>
	<link rel="stylesheet" href="css/thrillermovie.css">
</head>
<body>
<form method="POST" action="dramamovie.php">
		<nav class="main-menu">
	 		<div class="logo"></div>
			 	<ul>
                    <li><a href="homepage.php">Home</a></li>
					<li><a class="current" href="#">Movies</a></li>
                    <li><a href="voterprofile.php">Profile</a></li>
					<li><a href="#contact">Contact</a></li>
				</ul>
	 	</nav>

	<section id="about" >
		<div class="kilibili">
			<div class="about-us">
				<img src="img/dramamov1.jpg" height="330px" width="200px">
				<div class="about-us-left kilibili"><br>
				<h1>The Godfather(1972)</h1><br>
					<h3>The Godfather is a 1972 American crime film directed by Francis Ford Coppola who co-wrote the screenplay 
						with Mario Puzo, based on Puzo's best-selling 1969 novel of the same name.</h3><br>
					<h3>Director: Francis Ford Coppola</h3>
					<div style="text-align: center;"><img src="img/yt1.png" width="40px" height="100%"><a href="https://youtu.be/dNE2PvbesQU"> Watch Trailer</a></div>
						<div class="list">
							<ul>
								
								<li>IMDB: 9.2</li>
								<li>Rotten Tomatoes: 98%</li>
								<li>Metacritic: 100%</li>
								<li style="text-align: left;"><label style="text-align: center;">Personal Rating:<label>
									<input type="text" name="thrillerrating1" placeholder="Rate out of 10" ><br></li>
								<li style="text-align: left;"><label style="text-align: center;">Comment:<label>
									<input type="text" name="thrillercomment1"><br></li>
								<br>
							</ul>
						</div>
					<div style="text-align: center;"><input class="v1l" type="submit" name="v1l" value="Vote" required>
					</div>
			</div>
		</div>
	</section><hr><br>

	<section id="about" >
		<div class="kilibili">
			<div class="about-us">
				<img src="img/dramamov2.jpg" height="330px" width="200px">
				<div class="about-us-left kilibili"><br>
				<h1>12 Angry Men(1957)</h1><br>
					<h3>A dissenting juror in a murder trial slowly manages to convince the
						 others that the case is not as obviously clear as it seemed in court.12 Angry Men explores many techniques of consensus-building and the difficulties encountered
						  in the process among this group of men whose range of personalities adds to the intensity and conflict.</h3><br>
					<h3>Director: Sidney Lumet</h3>
					<div style="text-align: center;"><img src="img/yt1.png" width="40px" height="100%"><a href="https://youtu.be/K7M3DDylQSI"> Watch Trailer</a></div>
						<div class="list">
							<ul>
								
								<li>IMDB: 8.9</li>
								<li>Rotten Tomatoes: 100%</li>
								<li>Metacritic: 96%</li>
								<li style="text-align: left;"><label style="text-align: center;">Personal Rating:<label>
									<input type="text" name="thrillerrating2" placeholder="Rate out of 10" ><br></li>
								<li style="text-align: left;"><label style="text-align: center;">Comment:<label>
									<input type="text" name="thrillercomment2"><br></li>
								<br>
							</ul>
						</div>
					<div style="text-align: center;"><input class="v1l" type="submit" name="v2l" value="Vote" required>
					</div>
			</div>
		</div>
	</section><hr><br>
	

	<section id="about" >
		<div class="kilibili">
			<div class="about-us">
				<img src="img/dramamov3.jpg" height="330px" width="200px">
				<div class="about-us-left kilibili"><br>
				<h1>Schindler's List(1993)</h1><br>
					<h3>Oskar Schindler, a German industrialist and member of the Nazi party, tries to 
						save his Jewish employees after witnessing the persecution of Jews in Poland. It is a 
						1993 American epic historical drama film directed and produced by Steven Spielberg and written by Steven Zaillian.</h3><br>
					<h3>Director: Steven Spielberg</h3>
					<div style="text-align: center;"><img src="img/yt1.png" width="40px" height="100%"><a href="https://youtu.be/r3WVeWAAtA8"> Watch Trailer</a></div>
						<div class="list">
							<ul>
								
								<li>IMDB: 8.9</li>
								<li>Rotten Tomatoes: 97%</li>
								<li>Metacritic: 94%</li>
								<li style="text-align: left;"><label style="text-align: center;">Personal Rating:<label>
									<input type="text" name="thrillerrating3" placeholder="Rate out of 10" ><br></li>
								<li style="text-align: left;"><label style="text-align: center;">Comment:<label>
									<input type="text" name="thrillercomment3"><br></li>
								<br>
							</ul>
						</div>
					<div style="text-align: center;"><input class="v1l" type="submit" name="v3l" value="Vote" required>
					</div>
			</div>
		</div>
	</section><hr><br>

	<section id="about" >
		<div class="kilibili">
			<div class="about-us">
				<img src="img/dramamov4.jpg" height="100%" width="200px">
				<div class="about-us-left kilibili"><br>
				<h1>Spotlight(2015)</h1><br>
					<h3>Martin Baron joins the Boston Globe as an editor and pushes four journalists named Michael, Walter, Sacha and Matt to pursue
						 a story about the child molestation charges against the local church.</h3><br>
					<h3>Director: Tom McCarthy</h3>
					<div style="text-align: center;"><img src="img/yt1.png" width="40px" height="100%"><a href="https://youtu.be/Fc6OQy0nt6A"> Watch Trailer</a></div>
						<div class="list">
							<ul>
								
								<li>IMDB: 8.1</li>
								<li>Rotten Tomatoes: 97%</li>
								<li>Metacritic: 93%</li>
								<li style="text-align: left;"><label style="text-align: center;">Personal Rating:<label>
									<input type="text" name="thrillerrating4" placeholder="Rate out of 10" ><br></li>
								<li style="text-align: left;"><label style="text-align: center;">Comment:<label>
									<input type="text" name="thrillercomment4"><br></li>
								<br>
							</ul>
						</div>
					<div style="text-align: center;"><input class="v1l" type="submit" name="v4l" value="Vote" required>
					</div>
			</div>
		</div>
	</section><hr><br>

	<section id="about" >
		<div class="kilibili">
			<div class="about-us">
				<img src="img/dramamov5.jpg" height="100%" width="200px">
				<div class="about-us-left kilibili"><br>
				<h1>The Irishman(2019)</h1><br>
					<h3>In the 1950s, truck driver Frank Sheeran gets involved with Russell Bufalino and his Pennsylvania crime family. As Sheeran climbs the ranks to become a top hit man, he also goes
						 to work for Jimmy Hoffa- a powerful Teamster tied to organized crime.</h3><br>
					<h3>Director: Martin Scorsese</h3>
					<div style="text-align: center;"><img src="img/yt1.png" width="40px" height="100%"><a href="https://youtu.be/WHXxVmeGQUc"> Watch Trailer</a></div>
						<div class="list">
							<ul>
								
								<li>IMDB: 7.9</li>
								<li>Rotten Tomatoes: 96%</li>
								<li>Metacritic: 94%</li>
								<li style="text-align: left;"><label style="text-align: center;">Personal Rating:<label>
									<input type="text" name="thrillerrating5" placeholder="Rate out of 10" ><br></li>
								<li style="text-align: left;"><label style="text-align: center;">Comment:<label>
									<input type="text" name="thrillercomment5"><br></li>
								<br>
							</ul>
						</div>
					<div style="text-align: center;"><input class="v1l" type="submit" name="v5l" value="Vote" required>
					</div>
			</div>
		</div>
	</section><hr><br>
	

	<section id="about" >
		<div class="kilibili">
			<div class="about-us">
				<img src="img/dramamov6.jpg" height="100%" width="200px">
				<div class="about-us-left kilibili"><br>
				<h1>John Wick (2014)</h1><br>
					<h3>John Wick is an American neo-noir action-thriller media franchise created by screenwriter
						 Derek Kolstad and owned by Summit Entertainment. Keanu Reeves plays John Wick, a retired hitman seeking vengeance
						 for the killing of the dog given to him by his recently deceased wife.</h3><br>
					<h3>Director: Chad Stahelski</h3>
					<div style="text-align: center;"><img src="img/yt1.png" width="40px" height="100%"><a href="https://youtu.be/2AUmvWm5ZDQ"> Watch Trailer</a></div>
						<div class="list">
							<ul>
								
								<li>IMDB: 7.4</li>
								<li>Rotten Tomatoes: 87%</li>
								<li>Metacritic: 8.1</li>
								<li style="text-align: left;"><label style="text-align: center;">Personal Rating:<label>
									<input type="text" name="thrillerrating6" placeholder="Rate out of 10" ><br></li>
								<li style="text-align: left;"><label style="text-align: center;">Comment:<label>
									<input type="text" name="thrillercomment6"><br></li>
								<br>
							</ul>
						</div>
					<div style="text-align: center;"><input class="v1l" type="submit" name="v6l" value="Vote" required>
					</div>
			</div>
		</div>
	</section><br>
<!--
	<hr>
	<div style="text-align: center;"><input class="v1l" type="submit" name="logout" value="Logout" >
	</div>       
-->
</form>


<?php
	include 'footer.php';
?>
</body>
</html>