<?php
// Array with names
$a[] = "rifat@gmail.com";
$a[] = "nobel@gmail.com";
$a[] = "sadman@gmail.com";
$a[] = "akib@gmail.com";
$a[] = "badhon@gmail.com";
$a[] = "cat@gmail.com";
$a[] = "dihan@gmail.com";
$a[] = "eraj@gmail.com";
$a[] = "fardin@gmail.com";
$a[] = "golam@gmail.com";
$a[] = "harun@gmail.com";
$a[] = "ifaz@gmail.com";
$a[] = "jishan@gmail.com";
$a[] = "kamal@gmail.com";
$a[] = "labib@gmail.com";
$a[] = "mizan@gmail.com";
$a[] = "opu@gmail.com";
$a[] = "polash@gmail.com";
$a[] = "quader@gmail.com";
$a[] = "rasel@gmail.com";
$a[] = "tofayel@gmail.com";
$a[] = "urban@gmail.com";
$a[] = "veer@gmail.com";
$a[] = "watson@gmail.com";
$a[] = "yean@gmail.com";
$a[] = "zarif@gmail.com";


// get the q parameter from URL
$q = $_REQUEST["q"];

$hint = "";

// lookup all hints from array if $q is different from ""
if ($q !== "") {
  $q = strtolower($q);
  $len=strlen($q);
  foreach($a as $name) {
    if (stristr($q, substr($name, 0, $len))) {
      if ($hint === "") {
        $hint = $name;
      } else {
        $hint .= ", $name";
      }
    }
  }
}

// Output "no suggestion" if no hint was found or output correct values
echo $hint === "" ? "no suggestion" : $hint;
?>