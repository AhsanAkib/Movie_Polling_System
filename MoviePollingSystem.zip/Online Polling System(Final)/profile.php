<?php
include 'dash_style.php'; ?>
<?php
            session_start();
            $email=$_SESSION['email'];
            setcookie('identifier', 'Logged out', time()+200);
      ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Profile</title>
    <link rel="stylesheet" href="css/work.css">
    <link rel="stylesheet" href="css/sidebar.css">
</head>
<body>
<form method="POST" >
<div class="query"><marquee>I can see your profile too ;)</marquee></div>
<div id="sidebar" >
    <div class="toggle_button" onclick="toggleSidebar()">
        <span></span>
        <span></span>
        <span></span>
    </div>
    <ul>
        <li> <a href="AdminHome.php">Home</a></li>
        <li> <a href="addAdmin.php">Add Admin</a></li>
        <li> <a href="addMovie.php">Add Movie</a></li>
        <li> <a href="userinfo.php">User Information</a></li>
        <li> <a href="profile.php">Profile</a></li>
        <li> <a href="logout.php">Sign Out</a></li>
    </ul>
</div>

<script>
    function toggleSidebar(){
        document.getElementById("sidebar").classList.toggle('active');
    }
</script>
		<nav class="main-menu">
			 	<ul>
                 <li><a href="AdminHome.php">Home</a></li>
                    <li><a href="addAdmin.php" href="#">Add Admin</a></li>
                    <li><a href="addMovie.php" href="#">Add Movie</a></li>
                    <li><a href="userinfo.php" href="#">User</a></li>
                    <li><a class="current" href="#">Profile</a></li>
                    <li><a href="logout.php" href="#">Sign out</a></li>
				</ul>
            </nav>
<div class="button">
	<a href="editprofile.php" class="btn btn-primary">Edit Profile</a>
</div>
                <div class="table-responsive">
                <table class="table table-dark">
            <thead>
			<th>Name</th>
			<th>Email</th>
			<th>Address</th>
			<th>Phone</th>
			
		</thead>
		<tbody>
        <?php 
                $db = mysqli_connect("localhost", "root", "", "onlinepollingsystem");
                $selectq= " SELECT * FROM admin where email='$email' ";
                  $query = mysqli_query($db, $selectq);
                  while($row = mysqli_fetch_assoc($query))
                  {
                    ?>
                    <tr>
                    <td> <?php  echo $row["name"]; ?> </td>
                    <td> <?php  echo $row["email"]; ?> </td>
                    <td> <?php  echo $row["address"]; ?> </td>
                    <td> <?php  echo $row["phone"]; ?> </td>

                    </tr>
                    <?php 
                }
                
         ?>
			
		</tbody>
  </table>
                </div>
     
        
</form>

</body>
</html>