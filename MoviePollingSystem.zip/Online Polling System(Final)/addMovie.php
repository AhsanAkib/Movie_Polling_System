<?php
session_start();
$email=$_SESSION['email'];
setcookie('identifier', 'Logged out', time()+200);
$db = mysqli_connect("localhost", "root", "", "online_polling");

if(isset($_POST['add'])) {
    $mname = $_POST['mname'];
    $genre = $_POST['genre'];
    $description = $_POST['description'];
    $sql = "INSERT INTO movie(name, genre, description) VALUES('$mname', '$genre', '$description')";
    mysqli_query($db, $sql);
}

    
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Add Movie</title>
    <link rel="stylesheet" href="css/work.css">
    <link rel="stylesheet" href="css/sidebar.css">
</head>
<body>
<form method="POST" action="addMovie.php">
<div class="query"><marquee>Feel free to add latest movies!</marquee></div>
<div id="sidebar" >
    <div class="toggle_button" onclick="toggleSidebar()">
        <span></span>
        <span></span>
        <span></span>
    </div>
    <ul>
        <li> <a href="AdminHome.php">Home</a></li>
        <li> <a href="addAdmin.php">Add Admin</a></li>
        <li> <a href="addMovie.php">Add Movie</a></li>
        <li> <a href="userinfo.php">User Information</a></li>
        <li> <a href="profile.php">Profile</a></li>
        <li> <a href="logout.php">Sign Out</a></li>
    </ul>
</div>

<script>
    function toggleSidebar(){
        document.getElementById("sidebar").classList.toggle('active');
    }
</script>
		<nav class="main-menu">
			 	<ul>
                 <li><a href="AdminHome.php">Home</a></li>
                    <li><a href="addAdmin.php" href="#">Add Admin</a></li>
                    <li><a class="current" href="#">Add Movie</a></li>
                    <li><a href="userinfo.php" href="#">User</a></li>
                    <li><a href="profile.php" href="#">Profile</a></li>
                    <li><a href="logout.php" href="#">Sign out</a></li>
				</ul>
            </nav>
            <div>
                <section class="registerbox">
                    <h1>Add Movie</h1>
                    <div class="textbox">
                        <input type="text" placeholder="Enter Movie Name" name="mname">
        
                    </div>
                    <div class="textbox">
                    <input type="text" placeholder="Enter Genre" name="genre">
        
                    </div>
        
                    
                    <div class="textbox">
                        <input type="text" placeholder="Enter Description" name="description" >
        
                    </div>
                    <div >
                        <input class="btn"  type="submit" value="Add" name="add">
                    </div>
                </section>
                </div>
     
        
</form>

</body>
</html>